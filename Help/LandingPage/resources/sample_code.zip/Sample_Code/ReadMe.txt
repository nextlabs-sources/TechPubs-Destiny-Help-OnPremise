1) Extract the files into a work directory
2) Login into control center console as an administrator, navigate to policy management
3) Import the policies in the bin file, this will import
   Resource Type: Support Tickets and Resource, Subject and Action components
   and three sample policies
4) Use any Rest Client browser extension (like postman) and submit the payload in text as data
   This is a sample Json payload for a user,
   whose attributes are 
    *  Subject_id (unique identifier) = chris.webber
    *  department  = IT, 
    *  roles = Support Representative
    *  assigned_prod_area = SharePoint
    *  Authorization Request is to View support tickets
   and resource with attributes 
    *  Resource_id (unique identifier) = Ticket:1103
    *  Ticket = support

This request will match one of the allow policies you have uploaded and hence response is Allow
Please refer to Developers Guide for more details
